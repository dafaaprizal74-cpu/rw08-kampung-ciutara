# RW 08 Ciutara Android

Versi 1 aplikasi Android untuk portal layanan warga RW 08 Ciutara.

Fitur yang dibawa dari prototype: Pelayanan, Administrasi, Saran & Pengaduan, Pendataan, Pembayaran/Iuran (demo), Program RW, Pengumuman, dan Profil.

## Membuat APK gratis

Project ini dapat dibuka dengan Android Studio. Jika tidak punya komputer, folder ini juga memiliki GitHub Actions di `.github/workflows/build-apk.yml` untuk membuat APK debug secara gratis setelah project diunggah ke GitHub dan workflow dijalankan.

Catatan: APK ini masih versi awal/offline. Data warga, login, database online, notifikasi, dan pembayaran nyata membutuhkan backend dan integrasi layanan resmi sebelum dipakai produksi.
