package com.rw08ciutara.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(247, 250, 248));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        web.setWebViewClient(new WebViewClient());
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.loadUrl("file:///android_asset/index.html");

        setContentView(web);
    }

    @Override
    public void onBackPressed() {
        if (web != null) {
            // Kembali dari modal ke halaman utama sebelum keluar aplikasi.
            web.evaluateJavascript(
                "(function(){var m=document.getElementById('modal'); if(m && !m.classList.contains('hidden')){m.classList.add('hidden');m.setAttribute('aria-hidden','true');return true;} return false;})()",
                value -> {
                    if (!"true".equals(value)) finish();
                }
            );
        } else {
            super.onBackPressed();
        }
    }
}
