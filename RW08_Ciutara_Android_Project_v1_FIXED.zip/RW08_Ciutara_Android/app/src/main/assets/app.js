(() => {
  'use strict';

  const state = { role: 'Warga', name: 'Warga RW 08', requests: [], reports: [] };
  const modal = document.getElementById('modal');
  const content = document.getElementById('modalContent');

  const pages = {
    pelayanan: {
      title: 'Pelayanan Warga',
      html: '<div class="item action-item" data-request="Surat Pengantar">📄 Surat Pengantar <b>›</b></div>' +
            '<div class="item action-item" data-request="Surat Domisili">🏠 Surat Domisili <b>›</b></div>' +
            '<div class="item action-item" data-request="Surat Keterangan Usaha">💼 Surat Keterangan Usaha <b>›</b></div>' +
            '<div class="item action-item" data-request="Surat Keterangan Lainnya">📋 Surat Keterangan Lainnya <b>›</b></div>' +
            '<h3>Pengajuan Saya</h3><div id="requestList">Belum ada pengajuan.</div>'
    },
    administrasi: {
      title: 'Administrasi',
      html: '<div class="item">📑 Pengajuan Dokumen <b>›</b></div><div class="item">⏳ Status Pengajuan <b>›</b></div><div class="item">🗃️ Arsip Dokumen <b>›</b></div><div class="item">🔐 Verifikasi Data Warga <b>›</b></div>'
    },
    pengaduan: {
      title: 'Saran & Pengaduan',
      html: '<label>Judul laporan</label><input id="reportTitle" placeholder="Contoh: Lampu jalan mati"><label>Isi laporan</label><textarea id="reportBody" rows="4" placeholder="Jelaskan laporan Anda"></textarea><label>Lokasi</label><input id="reportLocation" placeholder="Contoh: Gang 3 RT 02"><button type="button" class="primary" id="sendReportBtn">Kirim Laporan</button><h3>Riwayat Laporan</h3><div id="reportList">Belum ada laporan.</div>'
    },
    pendataan: {
      title: 'Pendataan Warga',
      html: '<div class="item">👨‍👩‍👧 Data Keluarga <b>›</b></div><div class="item">👤 Data Anggota Keluarga <b>›</b></div><div class="item">🏠 Data Pendatang <b>›</b></div><p class="note">Data pribadi hanya ditampilkan sesuai hak akses Warga, RT, dan RW.</p>'
    },
    pembayaran: {
      title: 'Pembayaran & Iuran',
      html: '<div class="item action-item" data-pay="Kebersihan">🧹 Iuran Kebersihan <b>›</b></div><div class="item action-item" data-pay="Keamanan">🛡️ Iuran Keamanan <b>›</b></div><div class="item action-item" data-pay="Kegiatan RW">🎉 Kegiatan RW <b>›</b></div><div class="item">🧾 Riwayat Pembayaran <b>›</b></div><p class="note">Pada produksi, pembayaran akan diarahkan ke payment gateway resmi. Prototype ini tidak memproses uang nyata.</p>'
    },
    program: {
      title: 'Program RW',
      html: '<div class="item">🧹 Kerja Bakti <b>10 Agustus • 07.00</b></div><div class="item">🇮🇩 Persiapan HUT RI <b>9 Agustus • 19.00</b></div><div class="item">❤️ Kegiatan Sosial <b>Segera</b></div><div class="item">🏆 Lomba Warga <b>Segera</b></div>'
    },
    pengumuman: {
      title: 'Pengumuman',
      html: '<div class="item">📢 Kerja Bakti Lingkungan <b>›</b></div><div class="item">📢 Persiapan HUT RI <b>›</b></div><div class="item">📢 Layanan Surat Online <b>›</b></div>'
    },
    lainnya: {
      title: 'Menu Lainnya',
      html: '<div class="item">ℹ️ Tentang RW 08 <b>›</b></div><div class="item">☎️ Kontak Pengurus <b>›</b></div><div class="item">❓ Bantuan <b>›</b></div><div class="item">⚙️ Pengaturan <b>›</b></div>'
    },
    profil: {
      title: 'Profil Warga',
      html: () => '<div class="item">👤 Nama <b>' + state.name + '</b></div><div class="item">🏘️ Wilayah <b>RW 08 Ciutara</b></div><div class="item">🔐 Keamanan Akun <b>›</b></div><div class="item">👨‍💼 Peran <b>' + state.role + '</b></div><button type="button" class="primary" id="logoutBtn">Keluar</button>'
    }
  };

  function openPage(key) {
    const page = pages[key];
    if (!page) return;
    const html = typeof page.html === 'function' ? page.html() : page.html;
    content.innerHTML = '<h2>' + page.title + '</h2>' + html;
    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');
    if (key === 'pelayanan') renderRequests();
    if (key === 'pengaduan') {
      renderReports();
      document.getElementById('sendReportBtn').addEventListener('click', sendReport);
    }
    if (key === 'profil') document.getElementById('logoutBtn').addEventListener('click', logout);
  }

  function closeModal() {
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden', 'true');
  }

  function goHome() {
    closeModal();
    window.scrollTo(0, 0);
  }

  function showToast(message) {
    const old = document.querySelector('.toast');
    if (old) old.remove();
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2200);
  }

  function requestLetter(type) {
    state.requests.push({ type: type, status: 'Menunggu verifikasi RT' });
    showToast(type + ' berhasil diajukan');
    renderRequests();
  }

  function renderRequests() {
    const el = document.getElementById('requestList');
    if (!el) return;
    if (!state.requests.length) {
      el.textContent = 'Belum ada pengajuan.';
      return;
    }
    el.innerHTML = state.requests.map(x =>
      '<div class="item">📄 ' + x.type + '<small>' + x.status + '</small></div>'
    ).join('');
  }

  function sendReport() {
    const titleEl = document.getElementById('reportTitle');
    const bodyEl = document.getElementById('reportBody');
    const locEl = document.getElementById('reportLocation');
    const title = titleEl ? titleEl.value.trim() : '';
    const body = bodyEl ? bodyEl.value.trim() : '';
    const loc = locEl ? locEl.value.trim() : '';
    if (!title || !body) {
      showToast('Judul dan isi laporan wajib diisi');
      return;
    }
    state.reports.push({ title: title, body: body, loc: loc, status: 'Diterima' });
    showToast('Laporan berhasil dikirim');
    renderReports();
  }

  function renderReports() {
    const el = document.getElementById('reportList');
    if (!el) return;
    el.innerHTML = state.reports.length
      ? state.reports.map(x => '<div class="item"><span>💬 <b>' + escapeHtml(x.title) + '</b><small>' + escapeHtml(x.loc || 'Lokasi belum diisi') + ' • ' + x.status + '</small></span></div>').join('')
      : 'Belum ada laporan.';
  }

  function pay(type) {
    showToast('Pembayaran ' + type + ' siap dihubungkan ke payment gateway');
  }

  function logout() {
    state.name = 'Warga RW 08';
    const userName = document.getElementById('userName');
    if (userName) userName.textContent = state.name;
    closeModal();
    showToast('Anda telah keluar');
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[ch]);
  }

  document.addEventListener('click', event => {
    const pageButton = event.target.closest('[data-page]');
    if (pageButton) {
      event.preventDefault();
      openPage(pageButton.getAttribute('data-page'));
      return;
    }

    const actionButton = event.target.closest('[data-action]');
    if (actionButton) {
      event.preventDefault();
      const action = actionButton.getAttribute('data-action');
      if (action === 'close') closeModal();
      else if (action === 'home') goHome();
      else if (action === 'notifications') showToast('Anda memiliki 3 notifikasi');
      else if (action === 'scan') showToast('Fitur scan siap digunakan');
      return;
    }

    const request = event.target.closest('[data-request]');
    if (request) {
      requestLetter(request.getAttribute('data-request'));
      return;
    }

    const payment = event.target.closest('[data-pay]');
    if (payment) {
      pay(payment.getAttribute('data-pay'));
    }
  });

  // Menutup modal bila mengetuk area gelap di luar kotak.
  modal.addEventListener('click', event => {
    if (event.target === modal) closeModal();
  });

  // Tes kecil agar jika JavaScript aktif, halaman siap disentuh/diklik.
  document.documentElement.classList.add('js-ready');
})();
